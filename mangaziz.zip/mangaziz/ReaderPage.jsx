import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, 
  ChevronRight, 
  Settings, 
  Home, 
  List,
  Sun,
  Moon,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { mangaData } from '../data/mangaData';

const ReaderPage = () => {
  const { mangaId, chapterNumber } = useParams();
  const navigate = useNavigate();
  
  const [manga, setManga] = useState(null);
  const [currentChapter, setCurrentChapter] = useState(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [readerSettings, setReaderSettings] = useState({
    readingMode: 'vertical', // 'vertical' or 'horizontal'
    brightness: 100,
    zoom: 100,
    darkMode: true
  });

  // Mock page images (using placeholder images)
  const mockPages = [
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=1200&fit=crop',
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=1200&fit=crop',
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=1200&fit=crop',
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=1200&fit=crop',
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=1200&fit=crop'
  ];

  useEffect(() => {
    loadChapter();
  }, [mangaId, chapterNumber]);

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (showSettings) return;
      
      switch (e.key) {
        case 'ArrowLeft':
          previousPage();
          break;
        case 'ArrowRight':
          nextPage();
          break;
        case ' ':
          e.preventDefault();
          nextPage();
          break;
        case 'Escape':
          setShowControls(!showControls);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentPage, showControls, showSettings]);

  const loadChapter = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const foundManga = mangaData.find(m => m.id === mangaId);
    const foundChapter = foundManga?.chapters.find(c => c.number === parseInt(chapterNumber));
    
    if (foundManga && foundChapter) {
      setManga(foundManga);
      setCurrentChapter({
        ...foundChapter,
        pages: mockPages // Use mock pages
      });
      setCurrentPage(0);
    }
    
    setLoading(false);
  };

  const nextPage = useCallback(() => {
    if (!currentChapter) return;
    
    if (currentPage < currentChapter.pages.length - 1) {
      setCurrentPage(prev => prev + 1);
    } else {
      // Go to next chapter
      const nextChapter = manga.chapters.find(c => c.number === currentChapter.number + 1);
      if (nextChapter) {
        navigate(`/read/${mangaId}/${nextChapter.number}`);
      }
    }
  }, [currentPage, currentChapter, manga, mangaId, navigate]);

  const previousPage = useCallback(() => {
    if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    } else {
      // Go to previous chapter
      const prevChapter = manga?.chapters.find(c => c.number === currentChapter.number - 1);
      if (prevChapter) {
        navigate(`/read/${mangaId}/${prevChapter.number}`);
      }
    }
  }, [currentPage, currentChapter, manga, mangaId, navigate]);

  const goToPage = (pageIndex) => {
    setCurrentPage(pageIndex);
  };

  const toggleControls = () => {
    setShowControls(!showControls);
  };

  const updateSetting = (key, value) => {
    setReaderSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Loading chapter...</p>
        </div>
      </div>
    );
  }

  if (!manga || !currentChapter) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center text-white">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Chapter Not Found</h2>
          <Button onClick={() => navigate('/')} variant="outline">
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`fixed inset-0 ${readerSettings.darkMode ? 'bg-black' : 'bg-white'} overflow-hidden`}
      style={{ filter: `brightness(${readerSettings.brightness}%)` }}
    >
      {/* Top Controls */}
      {showControls && (
        <div className="fixed top-0 left-0 right-0 bg-black/80 backdrop-blur-sm text-white p-4 z-50 transition-transform duration-300">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(`/manga/${mangaId}`)}
                className="text-white hover:bg-white/20"
              >
                <Home size={18} />
              </Button>
              <div>
                <h1 className="font-semibold">{manga.title}</h1>
                <p className="text-sm text-white/70">
                  Chapter {currentChapter.number}: {currentChapter.title}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-white/20 text-white">
                {currentPage + 1} / {currentChapter.pages.length}
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(true)}
                className="text-white hover:bg-white/20"
              >
                <Settings size={18} />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Reader Content */}
      <div 
        className="h-full flex items-center justify-center cursor-pointer"
        onClick={toggleControls}
      >
        {readerSettings.readingMode === 'vertical' ? (
          // Vertical scrolling mode
          <div className="w-full max-w-4xl mx-auto px-4 py-8 space-y-2">
            {currentChapter.pages.map((page, index) => (
              <img
                key={index}
                src={page}
                alt={`Page ${index + 1}`}
                className="w-full h-auto mx-auto block"
                style={{ 
                  transform: `scale(${readerSettings.zoom / 100})`,
                  transformOrigin: 'center top'
                }}
                loading={index < 3 ? 'eager' : 'lazy'}
              />
            ))}
          </div>
        ) : (
          // Horizontal page-by-page mode
          <div className="relative w-full h-full flex items-center justify-center">
            <img
              src={currentChapter.pages[currentPage]}
              alt={`Page ${currentPage + 1}`}
              className="max-w-full max-h-full object-contain"
              style={{ 
                transform: `scale(${readerSettings.zoom / 100})`,
                transformOrigin: 'center'
              }}
            />
            
            {/* Navigation Areas */}
            <div 
              className="absolute left-0 top-0 w-1/3 h-full cursor-pointer flex items-center justify-start pl-4 hover:bg-black/10"
              onClick={(e) => {
                e.stopPropagation();
                previousPage();
              }}
            >
              {currentPage > 0 && (
                <ChevronLeft size={48} className="text-white/50 hover:text-white" />
              )}
            </div>
            
            <div 
              className="absolute right-0 top-0 w-1/3 h-full cursor-pointer flex items-center justify-end pr-4 hover:bg-black/10"
              onClick={(e) => {
                e.stopPropagation();
                nextPage();
              }}
            >
              {currentPage < currentChapter.pages.length - 1 && (
                <ChevronRight size={48} className="text-white/50 hover:text-white" />
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Controls */}
      {showControls && readerSettings.readingMode === 'horizontal' && (
        <div className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-sm text-white p-4 z-50">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={previousPage}
              disabled={currentPage === 0}
              className="text-white hover:bg-white/20 disabled:opacity-50"
            >
              <ChevronLeft size={18} />
              Previous
            </Button>
            
            {/* Page thumbnails */}
            <div className="flex items-center gap-2 overflow-x-auto max-w-md">
              {currentChapter.pages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToPage(index)}
                  className={`w-8 h-10 rounded border-2 flex-shrink-0 ${
                    index === currentPage 
                      ? 'border-white bg-white/20' 
                      : 'border-white/30 hover:border-white/60'
                  }`}
                >
                  <span className="text-xs">{index + 1}</span>
                </button>
              ))}
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={nextPage}
              disabled={currentPage === currentChapter.pages.length - 1}
              className="text-white hover:bg-white/20 disabled:opacity-50"
            >
              Next
              <ChevronRight size={18} />
            </Button>
          </div>
        </div>
      )}

      {/* Settings Panel */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-card rounded-lg p-6 w-full max-w-md mx-4 border border-border">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Reader Settings</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(false)}
              >
                <X size={18} />
              </Button>
            </div>
            
            <div className="space-y-6">
              {/* Reading Mode */}
              <div>
                <label className="text-sm font-medium mb-2 block">Reading Mode</label>
                <div className="flex gap-2">
                  <Button
                    variant={readerSettings.readingMode === 'vertical' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => updateSetting('readingMode', 'vertical')}
                  >
                    Vertical
                  </Button>
                  <Button
                    variant={readerSettings.readingMode === 'horizontal' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => updateSetting('readingMode', 'horizontal')}
                  >
                    Horizontal
                  </Button>
                </div>
              </div>
              
              {/* Brightness */}
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Brightness: {readerSettings.brightness}%
                </label>
                <input
                  type="range"
                  min="50"
                  max="150"
                  value={readerSettings.brightness}
                  onChange={(e) => updateSetting('brightness', parseInt(e.target.value))}
                  className="w-full"
                />
              </div>
              
              {/* Zoom */}
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Zoom: {readerSettings.zoom}%
                </label>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateSetting('zoom', Math.max(50, readerSettings.zoom - 25))}
                  >
                    <ZoomOut size={16} />
                  </Button>
                  <input
                    type="range"
                    min="50"
                    max="200"
                    value={readerSettings.zoom}
                    onChange={(e) => updateSetting('zoom', parseInt(e.target.value))}
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateSetting('zoom', Math.min(200, readerSettings.zoom + 25))}
                  >
                    <ZoomIn size={16} />
                  </Button>
                </div>
              </div>
              
              {/* Theme */}
              <div>
                <label className="text-sm font-medium mb-2 block">Theme</label>
                <div className="flex gap-2">
                  <Button
                    variant={readerSettings.darkMode ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => updateSetting('darkMode', true)}
                  >
                    <Moon size={16} className="mr-1" />
                    Dark
                  </Button>
                  <Button
                    variant={!readerSettings.darkMode ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => updateSetting('darkMode', false)}
                  >
                    <Sun size={16} className="mr-1" />
                    Light
                  </Button>
                </div>
              </div>
              
              {/* Reset */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setReaderSettings({
                  readingMode: 'vertical',
                  brightness: 100,
                  zoom: 100,
                  darkMode: true
                })}
                className="w-full"
              >
                <RotateCcw size={16} className="mr-1" />
                Reset to Default
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReaderPage;

