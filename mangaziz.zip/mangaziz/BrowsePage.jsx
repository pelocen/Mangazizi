import { useState, useEffect, useMemo } from 'react';
import { Search, Filter, X, SortAsc, SortDesc } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import MangaGrid from '../components/MangaGrid';
import { mangaData, genres } from '../data/mangaData';

const BrowsePage = () => {
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [sortBy, setSortBy] = useState('title');
  const [sortOrder, setSortOrder] = useState('asc');
  const [showFilters, setShowFilters] = useState(false);

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'ongoing', label: 'Ongoing' },
    { value: 'completed', label: 'Completed' },
    { value: 'hiatus', label: 'On Hiatus' },
  ];

  const sortOptions = [
    { value: 'title', label: 'Title' },
    { value: 'rating', label: 'Rating' },
    { value: 'publishedDate', label: 'Release Date' },
    { value: 'updatedDate', label: 'Last Updated' },
  ];

  useEffect(() => {
    loadManga();
  }, []);

  const loadManga = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 600));
    setManga(mangaData);
    setLoading(false);
  };

  const filteredAndSortedManga = useMemo(() => {
    let filtered = [...manga];

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(m => 
        m.title.toLowerCase().includes(query) ||
        m.author.toLowerCase().includes(query) ||
        m.genres.some(g => g.toLowerCase().includes(query)) ||
        m.description.toLowerCase().includes(query)
      );
    }

    // Filter by genres
    if (selectedGenres.length > 0) {
      filtered = filtered.filter(m => 
        selectedGenres.some(genre => m.genres.includes(genre))
      );
    }

    // Filter by status
    if (selectedStatus !== 'all') {
      filtered = filtered.filter(m => m.status === selectedStatus);
    }

    // Sort
    filtered.sort((a, b) => {
      let aValue = a[sortBy];
      let bValue = b[sortBy];

      if (sortBy === 'publishedDate' || sortBy === 'updatedDate') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (sortOrder === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

    return filtered;
  }, [manga, searchQuery, selectedGenres, selectedStatus, sortBy, sortOrder]);

  const toggleGenre = (genre) => {
    setSelectedGenres(prev => 
      prev.includes(genre) 
        ? prev.filter(g => g !== genre)
        : [...prev, genre]
    );
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedGenres([]);
    setSelectedStatus('all');
    setSortBy('title');
    setSortOrder('asc');
  };

  const toggleSort = () => {
    setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
  };

  return (
    <div className="min-h-screen bg-background pt-16 md:pt-20 pb-20 md:pb-8">
      <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Search className="text-primary" size={28} />
            <h1 className="text-3xl font-bold">Browse Manga</h1>
          </div>
          <p className="text-muted-foreground">
            Discover your next favorite manga series
          </p>
        </div>

        {/* Search and Filter Controls */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
            <Input
              placeholder="Search manga, authors, genres..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 h-12 text-base"
            />
          </div>

          {/* Filter Toggle and Sort */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <Filter size={16} />
                Filters
                {(selectedGenres.length > 0 || selectedStatus !== 'all') && (
                  <Badge variant="secondary" className="ml-1">
                    {selectedGenres.length + (selectedStatus !== 'all' ? 1 : 0)}
                  </Badge>
                )}
              </Button>
              
              {(selectedGenres.length > 0 || selectedStatus !== 'all' || searchQuery) && (
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  <X size={16} />
                  Clear
                </Button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-background border border-border rounded-md px-3 py-2 text-sm"
              >
                {sortOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <Button variant="outline" size="sm" onClick={toggleSort}>
                {sortOrder === 'asc' ? <SortAsc size={16} /> : <SortDesc size={16} />}
              </Button>
            </div>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <div className="bg-card border border-border rounded-lg p-6 space-y-6">
              {/* Status Filter */}
              <div>
                <h3 className="font-semibold mb-3">Status</h3>
                <div className="flex flex-wrap gap-2">
                  {statusOptions.map(status => (
                    <Button
                      key={status.value}
                      variant={selectedStatus === status.value ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedStatus(status.value)}
                    >
                      {status.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Genre Filter */}
              <div>
                <h3 className="font-semibold mb-3">Genres</h3>
                <div className="flex flex-wrap gap-2">
                  {genres.map(genre => (
                    <Button
                      key={genre}
                      variant={selectedGenres.includes(genre) ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => toggleGenre(genre)}
                    >
                      {genre}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results Summary */}
        <div className="mb-6 flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            {loading ? 'Loading...' : `${filteredAndSortedManga.length} manga found`}
          </div>
          
          {/* Active Filters */}
          {(selectedGenres.length > 0 || selectedStatus !== 'all') && (
            <div className="flex flex-wrap gap-2">
              {selectedStatus !== 'all' && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  Status: {statusOptions.find(s => s.value === selectedStatus)?.label}
                  <X 
                    size={12} 
                    className="cursor-pointer hover:text-destructive" 
                    onClick={() => setSelectedStatus('all')}
                  />
                </Badge>
              )}
              {selectedGenres.map(genre => (
                <Badge key={genre} variant="secondary" className="flex items-center gap-1">
                  {genre}
                  <X 
                    size={12} 
                    className="cursor-pointer hover:text-destructive" 
                    onClick={() => toggleGenre(genre)}
                  />
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Manga Grid */}
        <MangaGrid manga={filteredAndSortedManga} loading={loading} />

        {/* Load More Button */}
        {!loading && filteredAndSortedManga.length > 0 && (
          <div className="text-center mt-8">
            <Button variant="outline" size="lg">
              Load More
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default BrowsePage;

