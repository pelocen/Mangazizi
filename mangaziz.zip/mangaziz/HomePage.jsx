import { useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Carousel from '../components/Carousel';
import MangaGrid from '../components/MangaGrid';
import { mangaData, featuredBanners } from '../data/mangaData';

const HomePage = () => {
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadManga();
  }, []);

  const loadManga = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Sort by updated date to show latest updates first
    const sortedManga = [...mangaData].sort((a, b) => 
      new Date(b.updatedDate) - new Date(a.updatedDate)
    );
    
    setManga(sortedManga);
    setLoading(false);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadManga();
    setRefreshing(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Featured Banners */}
      <section className="mb-8">
        <Carousel 
          items={featuredBanners}
          autoPlay={true}
          interval={6000}
          className="h-48 md:h-64"
        />
      </section>

      {/* Latest Updates Section */}
      <section className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold mb-1">Latest Updates</h2>
            <p className="text-muted-foreground text-sm">
              Recently updated manga series
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2"
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            Refresh
          </Button>
        </div>

        <MangaGrid 
          manga={manga} 
          loading={loading}
          className="mb-8"
        />
      </section>

      {/* New Releases Section */}
      <section className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-1">New Releases</h2>
          <p className="text-muted-foreground text-sm">
            Fresh manga to discover
          </p>
        </div>

        <MangaGrid 
          manga={manga.filter(m => m.status === 'ongoing').slice(0, 6)} 
          loading={loading}
        />
      </section>

      {/* Popular This Week Section */}
      <section className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto mt-12 mb-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-1">Popular This Week</h2>
          <p className="text-muted-foreground text-sm">
            Trending manga everyone's reading
          </p>
        </div>

        <MangaGrid 
          manga={manga.sort((a, b) => b.rating - a.rating).slice(0, 6)} 
          loading={loading}
        />
      </section>
    </div>
  );
};

export default HomePage;

