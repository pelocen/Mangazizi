// Mock manga data for the application
export const mangaData = [
  {
    id: '1',
    title: 'Attack on Titan',
    author: 'Hajime Isayama',
    artist: 'Hajime Isayama',
    coverImage: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop',
    genres: ['Action', 'Drama', 'Fantasy'],
    status: 'completed',
    rating: 4.8,
    description: 'Humanity fights for survival against giant humanoid Titans. Eren Yeager vows to eliminate every Titan after they destroy his hometown and kill his mother.',
    chapters: [
      { id: '1-1', number: 1, title: 'To You, in 2000 Years', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-01' },
      { id: '1-2', number: 2, title: 'That Day', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-08' }
    ],
    tags: ['Popular', 'Completed'],
    publishedDate: '2009-09-09',
    updatedDate: '2023-12-01'
  },
  {
    id: '2',
    title: 'One Piece',
    author: 'Eiichiro Oda',
    artist: 'Eiichiro Oda',
    coverImage: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop',
    genres: ['Adventure', 'Comedy', 'Action'],
    status: 'ongoing',
    rating: 4.9,
    description: 'Monkey D. Luffy explores the Grand Line with his diverse crew of pirates, named the Straw Hat Pirates, to find the world\'s ultimate treasure known as "One Piece".',
    chapters: [
      { id: '2-1', number: 1, title: 'Romance Dawn', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-01' },
      { id: '2-2', number: 2, title: 'They Call Him "Straw Hat Luffy"', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-08' }
    ],
    tags: ['Popular', 'Long Running'],
    publishedDate: '1997-07-22',
    updatedDate: '2024-01-15'
  },
  {
    id: '3',
    title: 'Demon Slayer',
    author: 'Koyoharu Gotouge',
    artist: 'Koyoharu Gotouge',
    coverImage: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop',
    genres: ['Action', 'Supernatural', 'Historical'],
    status: 'completed',
    rating: 4.7,
    description: 'Tanjiro Kamado becomes a demon slayer to save his sister Nezuko, who has been turned into a demon, and avenge his family who were killed by demons.',
    chapters: [
      { id: '3-1', number: 1, title: 'Cruelty', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-01' },
      { id: '3-2', number: 2, title: 'Stranger', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-08' }
    ],
    tags: ['Popular', 'Anime Adapted'],
    publishedDate: '2016-02-15',
    updatedDate: '2023-11-20'
  },
  {
    id: '4',
    title: 'My Hero Academia',
    author: 'Kohei Horikoshi',
    artist: 'Kohei Horikoshi',
    coverImage: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop',
    genres: ['Action', 'School', 'Superhero'],
    status: 'ongoing',
    rating: 4.6,
    description: 'In a world where most people have superpowers called "Quirks," Izuku Midoriya dreams of becoming a hero despite being born without any powers.',
    chapters: [
      { id: '4-1', number: 1, title: 'Izuku Midoriya: Origin', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-01' },
      { id: '4-2', number: 2, title: 'What It Takes to Be a Hero', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-08' }
    ],
    tags: ['Popular', 'School Life'],
    publishedDate: '2014-07-07',
    updatedDate: '2024-01-10'
  },
  {
    id: '5',
    title: 'Jujutsu Kaisen',
    author: 'Gege Akutami',
    artist: 'Gege Akutami',
    coverImage: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop',
    genres: ['Action', 'Supernatural', 'School'],
    status: 'ongoing',
    rating: 4.8,
    description: 'Yuji Itadori joins a secret organization of Jujutsu Sorcerers to kill a powerful Curse named Ryomen Sukuna, of whom Yuji becomes the host.',
    chapters: [
      { id: '5-1', number: 1, title: 'Ryomen Sukuna', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-01' },
      { id: '5-2', number: 2, title: 'For Myself', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-08' }
    ],
    tags: ['Popular', 'Dark'],
    publishedDate: '2018-03-05',
    updatedDate: '2024-01-12'
  },
  {
    id: '6',
    title: 'Chainsaw Man',
    author: 'Tatsuki Fujimoto',
    artist: 'Tatsuki Fujimoto',
    coverImage: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop',
    genres: ['Action', 'Supernatural', 'Dark'],
    status: 'ongoing',
    rating: 4.7,
    description: 'Denji becomes a Devil Hunter to pay off his debt, but after merging with his pet devil Pochita, he gains the ability to transform parts of his body into chainsaws.',
    chapters: [
      { id: '6-1', number: 1, title: 'Dog & Chainsaw', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-01' },
      { id: '6-2', number: 2, title: 'The Place Where Pochita Is', pages: ['page1.jpg', 'page2.jpg'], publishedDate: '2023-01-08' }
    ],
    tags: ['Popular', 'Gore'],
    publishedDate: '2018-12-03',
    updatedDate: '2024-01-05'
  }
];

export const creators = [
  {
    id: '1',
    name: 'Hajime Isayama',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    works: ['Attack on Titan'],
    bio: 'Japanese manga artist best known for creating Attack on Titan.'
  },
  {
    id: '2',
    name: 'Eiichiro Oda',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    works: ['One Piece'],
    bio: 'Japanese manga artist and creator of the series One Piece.'
  },
  {
    id: '3',
    name: 'Koyoharu Gotouge',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616c9c0e8e0?w=150&h=150&fit=crop&crop=face',
    works: ['Demon Slayer'],
    bio: 'Japanese manga artist known for creating Demon Slayer: Kimetsu no Yaiba.'
  }
];

export const genres = [
  'Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Mystery', 
  'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller',
  'Historical', 'School', 'Superhero', 'Dark'
];

export const featuredBanners = [
  {
    id: '1',
    title: 'Limited Time Deluxe Plan Discount',
    subtitle: '50% OFF Premium Features',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=300&fit=crop',
    link: '/premium'
  },
  {
    id: '2',
    title: 'New Chapter Alert',
    subtitle: 'Attack on Titan Final Chapter',
    image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=300&fit=crop',
    link: '/manga/1'
  }
];

