import { useState, useEffect } from 'react';
import { TrendingUp, Flame, Clock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MangaGrid from '../components/MangaGrid';
import { mangaData } from '../data/mangaData';

const HotPage = () => {
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);
  const [timeFilter, setTimeFilter] = useState('week');

  const timeFilters = [
    { value: 'day', label: 'Today', icon: Clock },
    { value: 'week', label: 'This Week', icon: Calendar },
    { value: 'month', label: 'This Month', icon: TrendingUp },
    { value: 'all', label: 'All Time', icon: Flame },
  ];

  useEffect(() => {
    loadHotManga();
  }, [timeFilter]);

  const loadHotManga = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Sort by rating and simulate different time periods
    let sortedManga = [...mangaData].sort((a, b) => b.rating - a.rating);
    
    // Simulate different results for different time periods
    if (timeFilter === 'day') {
      sortedManga = sortedManga.filter(m => m.status === 'ongoing');
    } else if (timeFilter === 'week') {
      sortedManga = sortedManga.slice(0, 8);
    } else if (timeFilter === 'month') {
      sortedManga = sortedManga.slice(0, 10);
    }
    
    setManga(sortedManga);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background pt-16 md:pt-20 pb-20 md:pb-8">
      <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Flame className="text-orange-500" size={28} />
            <h1 className="text-3xl font-bold">Hot Manga</h1>
          </div>
          <p className="text-muted-foreground">
            Discover the most popular and trending manga series
          </p>
        </div>

        {/* Time Filter Buttons */}
        <div className="flex flex-wrap gap-2 mb-8">
          {timeFilters.map(({ value, label, icon: Icon }) => (
            <Button
              key={value}
              variant={timeFilter === value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setTimeFilter(value)}
              className="flex items-center gap-2"
            >
              <Icon size={16} />
              {label}
            </Button>
          ))}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card rounded-lg p-4 border border-border">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="text-green-500" size={20} />
              <span className="text-sm font-medium">Trending</span>
            </div>
            <div className="text-2xl font-bold">{manga.length}</div>
            <div className="text-xs text-muted-foreground">Active series</div>
          </div>
          
          <div className="bg-card rounded-lg p-4 border border-border">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="text-orange-500" size={20} />
              <span className="text-sm font-medium">Hot</span>
            </div>
            <div className="text-2xl font-bold">
              {manga.filter(m => m.rating >= 4.7).length}
            </div>
            <div className="text-xs text-muted-foreground">High rated</div>
          </div>
          
          <div className="bg-card rounded-lg p-4 border border-border">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="text-blue-500" size={20} />
              <span className="text-sm font-medium">Updated</span>
            </div>
            <div className="text-2xl font-bold">
              {manga.filter(m => m.status === 'ongoing').length}
            </div>
            <div className="text-xs text-muted-foreground">This week</div>
          </div>
          
          <div className="bg-card rounded-lg p-4 border border-border">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="text-purple-500" size={20} />
              <span className="text-sm font-medium">New</span>
            </div>
            <div className="text-2xl font-bold">
              {manga.filter(m => new Date(m.publishedDate) > new Date('2020-01-01')).length}
            </div>
            <div className="text-xs text-muted-foreground">Recent releases</div>
          </div>
        </div>

        {/* Hot Manga Grid */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <TrendingUp size={20} />
            {timeFilters.find(f => f.value === timeFilter)?.label} Trending
          </h2>
          <MangaGrid manga={manga} loading={loading} />
        </div>

        {/* Load More Button */}
        {!loading && manga.length > 0 && (
          <div className="text-center mt-8">
            <Button variant="outline" size="lg">
              Load More
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default HotPage;

