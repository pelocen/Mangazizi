import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Star, 
  Heart, 
  BookOpen, 
  Download, 
  Share2, 
  Calendar,
  User,
  Tag,
  Clock,
  CheckCircle,
  Pause,
  Play
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { mangaData } from '../data/mangaData';

const MangaDetailsPage = () => {
  const { id } = useParams();
  const [manga, setManga] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isInShelf, setIsInShelf] = useState(false);
  const [expandedDescription, setExpandedDescription] = useState(false);

  useEffect(() => {
    loadMangaDetails();
  }, [id]);

  const loadMangaDetails = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const foundManga = mangaData.find(m => m.id === id);
    setManga(foundManga);
    
    // Mock user preferences
    setIsFavorite(Math.random() > 0.5);
    setIsInShelf(Math.random() > 0.5);
    
    setLoading(false);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'ongoing':
        return <Clock size={16} className="text-green-500" />;
      case 'completed':
        return <CheckCircle size={16} className="text-blue-500" />;
      case 'hiatus':
        return <Pause size={16} className="text-yellow-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ongoing':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'completed':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'hiatus':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  const toggleShelf = () => {
    setIsInShelf(!isInShelf);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pt-16 md:pt-20 pb-20 md:pb-8">
        <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="flex flex-col md:flex-row gap-8 mb-8">
              <div className="w-full md:w-80 aspect-[3/4] bg-muted rounded-lg"></div>
              <div className="flex-1 space-y-4">
                <div className="h-8 bg-muted rounded w-3/4"></div>
                <div className="h-6 bg-muted rounded w-1/2"></div>
                <div className="h-20 bg-muted rounded"></div>
                <div className="flex gap-2">
                  <div className="h-10 bg-muted rounded w-24"></div>
                  <div className="h-10 bg-muted rounded w-24"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!manga) {
    return (
      <div className="min-h-screen bg-background pt-16 md:pt-20 pb-20 md:pb-8 flex items-center justify-center">
        <div className="text-center">
          <div className="text-2xl font-bold mb-2">Manga Not Found</div>
          <p className="text-muted-foreground mb-4">The manga you're looking for doesn't exist.</p>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-16 md:pt-20 pb-20 md:pb-8">
      <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="flex flex-col md:flex-row gap-8 mb-8">
          {/* Cover Image */}
          <div className="w-full md:w-80 flex-shrink-0">
            <div className="aspect-[3/4] relative overflow-hidden rounded-lg border border-border">
              <img
                src={manga.coverImage}
                alt={manga.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4">
                <Badge className={`${getStatusColor(manga.status)}`}>
                  <span className="flex items-center gap-1">
                    {getStatusIcon(manga.status)}
                    {manga.status.toUpperCase()}
                  </span>
                </Badge>
              </div>
              <div className="absolute top-4 right-4">
                <Badge variant="secondary" className="bg-black/50 text-white border-white/20">
                  <Star size={12} className="fill-yellow-400 text-yellow-400 mr-1" />
                  {manga.rating}
                </Badge>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{manga.title}</h1>
            
            <div className="flex items-center gap-4 mb-4 text-muted-foreground">
              <div className="flex items-center gap-1">
                <User size={16} />
                <span>by {manga.author}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar size={16} />
                <span>{new Date(manga.publishedDate).getFullYear()}</span>
              </div>
            </div>

            {/* Genres */}
            <div className="flex flex-wrap gap-2 mb-4">
              {manga.genres.map(genre => (
                <Badge key={genre} variant="outline" className="flex items-center gap-1">
                  <Tag size={12} />
                  {genre}
                </Badge>
              ))}
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-6">
              {manga.tags.map(tag => (
                <Badge key={tag} variant="secondary">
                  {tag}
                </Badge>
              ))}
            </div>

            {/* Description */}
            <div className="mb-6">
              <p className={`text-muted-foreground leading-relaxed ${
                expandedDescription ? '' : 'line-clamp-3'
              }`}>
                {manga.description}
              </p>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setExpandedDescription(!expandedDescription)}
                className="mt-2 p-0 h-auto text-primary hover:bg-transparent"
              >
                {expandedDescription ? 'Show Less' : 'Read More'}
              </Button>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 mb-6">
              <Link to={`/read/${manga.id}/1`}>
                <Button size="lg" className="flex items-center gap-2">
                  <Play size={18} />
                  Start Reading
                </Button>
              </Link>
              
              <Button
                variant={isFavorite ? 'default' : 'outline'}
                size="lg"
                onClick={toggleFavorite}
                className="flex items-center gap-2"
              >
                <Heart size={18} className={isFavorite ? 'fill-current' : ''} />
                {isFavorite ? 'Favorited' : 'Add to Favorites'}
              </Button>
              
              <Button
                variant={isInShelf ? 'default' : 'outline'}
                size="lg"
                onClick={toggleShelf}
                className="flex items-center gap-2"
              >
                <BookOpen size={18} />
                {isInShelf ? 'In Shelf' : 'Add to Shelf'}
              </Button>
              
              <Button variant="outline" size="lg" className="flex items-center gap-2">
                <Download size={18} />
                Download
              </Button>
              
              <Button variant="outline" size="lg" className="flex items-center gap-2">
                <Share2 size={18} />
                Share
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-card rounded-lg p-4 border border-border text-center">
                <div className="text-2xl font-bold text-primary">{manga.rating}</div>
                <div className="text-sm text-muted-foreground">Rating</div>
              </div>
              <div className="bg-card rounded-lg p-4 border border-border text-center">
                <div className="text-2xl font-bold text-green-500">{manga.chapters.length}</div>
                <div className="text-sm text-muted-foreground">Chapters</div>
              </div>
              <div className="bg-card rounded-lg p-4 border border-border text-center">
                <div className="text-2xl font-bold text-blue-500">
                  {manga.status === 'ongoing' ? 'Ongoing' : 'Complete'}
                </div>
                <div className="text-sm text-muted-foreground">Status</div>
              </div>
              <div className="bg-card rounded-lg p-4 border border-border text-center">
                <div className="text-2xl font-bold text-purple-500">
                  {new Date(manga.updatedDate).getFullYear()}
                </div>
                <div className="text-sm text-muted-foreground">Updated</div>
              </div>
            </div>
          </div>
        </div>

        {/* Chapters List */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Chapters</h2>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                Sort by Latest
              </Button>
              <Button variant="outline" size="sm">
                Download All
              </Button>
            </div>
          </div>

          <div className="bg-card rounded-lg border border-border overflow-hidden">
            {manga.chapters.map((chapter, index) => (
              <Link
                key={chapter.id}
                to={`/read/${manga.id}/${chapter.number}`}
                className="flex items-center justify-between p-4 hover:bg-accent transition-colors border-b border-border last:border-b-0"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <span className="font-semibold text-primary">{chapter.number}</span>
                  </div>
                  <div>
                    <h3 className="font-medium">{chapter.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(chapter.publishedDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {chapter.pages.length} pages
                  </Badge>
                  <Button variant="ghost" size="sm">
                    <Download size={16} />
                  </Button>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Related/Recommended */}
        <div>
          <h2 className="text-2xl font-bold mb-6">You Might Also Like</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {mangaData
              .filter(m => m.id !== manga.id && m.genres.some(g => manga.genres.includes(g)))
              .slice(0, 6)
              .map(relatedManga => (
                <Link
                  key={relatedManga.id}
                  to={`/manga/${relatedManga.id}`}
                  className="group block"
                >
                  <div className="aspect-[3/4] relative overflow-hidden rounded-lg border border-border mb-2">
                    <img
                      src={relatedManga.coverImage}
                      alt={relatedManga.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <h3 className="font-medium text-sm line-clamp-2 group-hover:text-primary transition-colors">
                    {relatedManga.title}
                  </h3>
                  <p className="text-xs text-muted-foreground">{relatedManga.author}</p>
                </Link>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MangaDetailsPage;

