import { useState, useEffect } from 'react';
import { Users, Search, BookOpen, Star } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { creators, mangaData } from '../data/mangaData';

const CreatorsPage = () => {
  const [creatorsData, setCreatorsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadCreators();
  }, []);

  const loadCreators = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Enhance creators data with manga statistics
    const enhancedCreators = creators.map(creator => {
      const creatorManga = mangaData.filter(manga => 
        manga.author === creator.name || manga.artist === creator.name
      );
      
      const totalRating = creatorManga.reduce((sum, manga) => sum + manga.rating, 0);
      const averageRating = creatorManga.length > 0 ? totalRating / creatorManga.length : 0;
      
      return {
        ...creator,
        manga: creatorManga,
        totalWorks: creatorManga.length,
        averageRating: averageRating.toFixed(1),
        totalChapters: creatorManga.reduce((sum, manga) => sum + manga.chapters.length, 0)
      };
    });
    
    setCreatorsData(enhancedCreators);
    setLoading(false);
  };

  const filteredCreators = creatorsData.filter(creator =>
    creator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    creator.bio.toLowerCase().includes(searchQuery.toLowerCase()) ||
    creator.works.some(work => work.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const CreatorCard = ({ creator }) => (
    <div className="bg-card rounded-lg border border-border p-6 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10">
      <div className="flex items-start gap-4 mb-4">
        <img
          src={creator.avatar}
          alt={creator.name}
          className="w-16 h-16 rounded-full object-cover border-2 border-border"
        />
        <div className="flex-1">
          <h3 className="text-lg font-semibold mb-1">{creator.name}</h3>
          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
            {creator.bio}
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <BookOpen size={12} />
              <span>{creator.totalWorks} works</span>
            </div>
            <div className="flex items-center gap-1">
              <Star size={12} className="fill-yellow-400 text-yellow-400" />
              <span>{creator.averageRating}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Works */}
      <div className="mb-4">
        <h4 className="text-sm font-medium mb-2">Popular Works</h4>
        <div className="flex flex-wrap gap-1">
          {creator.manga.slice(0, 3).map((manga) => (
            <Badge key={manga.id} variant="outline" className="text-xs">
              {manga.title}
            </Badge>
          ))}
          {creator.manga.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{creator.manga.length - 3} more
            </Badge>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
        <div className="text-center">
          <div className="text-lg font-semibold">{creator.totalWorks}</div>
          <div className="text-xs text-muted-foreground">Works</div>
        </div>
        <div className="text-center">
          <div className="text-lg font-semibold">{creator.totalChapters}</div>
          <div className="text-xs text-muted-foreground">Chapters</div>
        </div>
        <div className="text-center">
          <div className="text-lg font-semibold">{creator.averageRating}</div>
          <div className="text-xs text-muted-foreground">Rating</div>
        </div>
      </div>
    </div>
  );

  const LoadingSkeleton = () => (
    <div className="bg-card rounded-lg border border-border p-6 animate-pulse">
      <div className="flex items-start gap-4 mb-4">
        <div className="w-16 h-16 bg-muted rounded-full"></div>
        <div className="flex-1 space-y-2">
          <div className="h-5 bg-muted rounded w-1/2"></div>
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-3 bg-muted rounded w-1/3"></div>
        </div>
      </div>
      <div className="space-y-2 mb-4">
        <div className="h-4 bg-muted rounded w-1/4"></div>
        <div className="flex gap-2">
          <div className="h-6 bg-muted rounded w-16"></div>
          <div className="h-6 bg-muted rounded w-20"></div>
          <div className="h-6 bg-muted rounded w-14"></div>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="text-center space-y-1">
            <div className="h-6 bg-muted rounded w-8 mx-auto"></div>
            <div className="h-3 bg-muted rounded w-12 mx-auto"></div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background pt-16 md:pt-20 pb-20 md:pb-8">
      <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Users className="text-primary" size={28} />
            <h1 className="text-3xl font-bold">Creators</h1>
          </div>
          <p className="text-muted-foreground">
            Meet the talented artists and authors behind your favorite manga
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
            <Input
              placeholder="Search creators..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card rounded-lg p-4 border border-border text-center">
            <div className="text-2xl font-bold text-primary">{creatorsData.length}</div>
            <div className="text-sm text-muted-foreground">Total Creators</div>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border text-center">
            <div className="text-2xl font-bold text-green-500">
              {creatorsData.reduce((sum, creator) => sum + creator.totalWorks, 0)}
            </div>
            <div className="text-sm text-muted-foreground">Total Works</div>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border text-center">
            <div className="text-2xl font-bold text-blue-500">
              {creatorsData.reduce((sum, creator) => sum + creator.totalChapters, 0)}
            </div>
            <div className="text-sm text-muted-foreground">Total Chapters</div>
          </div>
          <div className="bg-card rounded-lg p-4 border border-border text-center">
            <div className="text-2xl font-bold text-yellow-500">
              {creatorsData.length > 0 ? 
                (creatorsData.reduce((sum, creator) => sum + parseFloat(creator.averageRating), 0) / creatorsData.length).toFixed(1) 
                : '0.0'
              }
            </div>
            <div className="text-sm text-muted-foreground">Avg Rating</div>
          </div>
        </div>

        {/* Results Summary */}
        <div className="mb-6">
          <div className="text-sm text-muted-foreground">
            {loading ? 'Loading...' : `${filteredCreators.length} creators found`}
          </div>
        </div>

        {/* Creators Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            Array.from({ length: 6 }).map((_, index) => (
              <LoadingSkeleton key={index} />
            ))
          ) : filteredCreators.length > 0 ? (
            filteredCreators.map((creator) => (
              <CreatorCard key={creator.id} creator={creator} />
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <Users className="mx-auto text-muted-foreground mb-4" size={48} />
              <div className="text-muted-foreground mb-2">No creators found</div>
              <p className="text-sm text-muted-foreground">Try adjusting your search terms</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreatorsPage;

