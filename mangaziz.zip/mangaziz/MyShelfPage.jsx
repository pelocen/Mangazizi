import { useState, useEffect } from 'react';
import { BookOpen, Heart, CheckCircle, Download, Clock, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import MangaGrid from '../components/MangaGrid';
import { mangaData } from '../data/mangaData';

const MyShelfPage = () => {
  const [activeTab, setActiveTab] = useState('favorites');
  const [shelfData, setShelfData] = useState({
    favorites: [],
    reading: [],
    completed: [],
    downloaded: []
  });
  const [loading, setLoading] = useState(true);

  const tabs = [
    { 
      id: 'favorites', 
      label: 'Favorites', 
      icon: Heart, 
      color: 'text-red-500',
      description: 'Your favorite manga series'
    },
    { 
      id: 'reading', 
      label: 'Reading', 
      icon: BookOpen, 
      color: 'text-blue-500',
      description: 'Currently reading'
    },
    { 
      id: 'completed', 
      label: 'Completed', 
      icon: CheckCircle, 
      color: 'text-green-500',
      description: 'Finished reading'
    },
    { 
      id: 'downloaded', 
      label: 'Downloaded', 
      icon: Download, 
      color: 'text-purple-500',
      description: 'Available offline'
    }
  ];

  useEffect(() => {
    loadShelfData();
  }, []);

  const loadShelfData = async () => {
    setLoading(true);
    // Simulate API call and user data
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock user shelf data
    const mockShelfData = {
      favorites: mangaData.slice(0, 3),
      reading: mangaData.filter(m => m.status === 'ongoing').slice(0, 4),
      completed: mangaData.filter(m => m.status === 'completed'),
      downloaded: mangaData.slice(1, 3)
    };
    
    setShelfData(mockShelfData);
    setLoading(false);
  };

  const getReadingProgress = (manga) => {
    // Mock reading progress
    const totalChapters = manga.chapters.length;
    const readChapters = Math.floor(Math.random() * totalChapters) + 1;
    return { read: readChapters, total: totalChapters };
  };

  const removeFromShelf = (mangaId, shelfType) => {
    setShelfData(prev => ({
      ...prev,
      [shelfType]: prev[shelfType].filter(manga => manga.id !== mangaId)
    }));
  };

  const ShelfStats = () => (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {tabs.map(tab => {
        const Icon = tab.icon;
        const count = shelfData[tab.id]?.length || 0;
        
        return (
          <div key={tab.id} className="bg-card rounded-lg p-4 border border-border">
            <div className="flex items-center gap-2 mb-2">
              <Icon className={tab.color} size={20} />
              <span className="text-sm font-medium">{tab.label}</span>
            </div>
            <div className="text-2xl font-bold">{count}</div>
            <div className="text-xs text-muted-foreground">
              {count === 1 ? 'series' : 'series'}
            </div>
          </div>
        );
      })}
    </div>
  );

  const ReadingProgressCard = ({ manga }) => {
    const progress = getReadingProgress(manga);
    const percentage = (progress.read / progress.total) * 100;

    return (
      <div className="bg-card rounded-lg border border-border p-4 mb-4">
        <div className="flex items-start gap-4">
          <img
            src={manga.coverImage}
            alt={manga.title}
            className="w-16 h-20 object-cover rounded"
          />
          <div className="flex-1">
            <h3 className="font-semibold mb-1">{manga.title}</h3>
            <p className="text-sm text-muted-foreground mb-2">by {manga.author}</p>
            
            <div className="mb-2">
              <div className="flex justify-between text-sm mb-1">
                <span>Progress</span>
                <span>{progress.read}/{progress.total} chapters</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button size="sm" variant="default">
                Continue Reading
              </Button>
              <Button 
                size="sm" 
                variant="ghost"
                onClick={() => removeFromShelf(manga.id, 'reading')}
              >
                <Trash2 size={14} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const currentTab = tabs.find(tab => tab.id === activeTab);
  const currentData = shelfData[activeTab] || [];

  return (
    <div className="min-h-screen bg-background pt-16 md:pt-20 pb-20 md:pb-8">
      <div className="px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <BookOpen className="text-primary" size={28} />
            <h1 className="text-3xl font-bold">My Shelf</h1>
          </div>
          <p className="text-muted-foreground">
            Manage your personal manga collection
          </p>
        </div>

        {/* Stats */}
        <ShelfStats />

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-8 border-b border-border">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            const count = shelfData[tab.id]?.length || 0;
            
            return (
              <Button
                key={tab.id}
                variant={isActive ? 'default' : 'ghost'}
                className={`flex items-center gap-2 rounded-b-none border-b-2 ${
                  isActive ? 'border-primary' : 'border-transparent'
                }`}
                onClick={() => setActiveTab(tab.id)}
              >
                <Icon size={16} className={isActive ? '' : tab.color} />
                {tab.label}
                {count > 0 && (
                  <Badge variant="secondary" className="ml-1">
                    {count}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            {currentTab && (
              <>
                <currentTab.icon className={currentTab.color} size={20} />
                <h2 className="text-xl font-semibold">{currentTab.label}</h2>
              </>
            )}
          </div>
          <p className="text-sm text-muted-foreground mb-6">
            {currentTab?.description}
          </p>

          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-2">Loading your shelf...</p>
            </div>
          ) : currentData.length === 0 ? (
            <div className="text-center py-12">
              {currentTab && <currentTab.icon className={`mx-auto mb-4 ${currentTab.color}`} size={48} />}
              <div className="text-muted-foreground mb-2">
                No manga in {currentTab?.label.toLowerCase()}
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Start building your collection by adding manga to your shelf
              </p>
              <Button variant="outline">
                Browse Manga
              </Button>
            </div>
          ) : (
            <>
              {/* Special layout for reading tab */}
              {activeTab === 'reading' ? (
                <div className="space-y-4">
                  {currentData.map(manga => (
                    <ReadingProgressCard key={manga.id} manga={manga} />
                  ))}
                </div>
              ) : (
                <MangaGrid manga={currentData} />
              )}
              
              {/* Additional actions */}
              <div className="mt-8 flex justify-center gap-4">
                <Button variant="outline">
                  Export List
                </Button>
                <Button variant="outline">
                  Import from File
                </Button>
              </div>
            </>
          )}
        </div>

        {/* Recent Activity */}
        <div className="mt-12">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Clock size={20} />
            Recent Activity
          </h3>
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Completed reading <strong>Attack on Titan</strong></span>
                <span className="text-muted-foreground ml-auto">2 hours ago</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Added <strong>Chainsaw Man</strong> to favorites</span>
                <span className="text-muted-foreground ml-auto">1 day ago</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span>Downloaded <strong>One Piece</strong> chapters 1-10</span>
                <span className="text-muted-foreground ml-auto">3 days ago</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyShelfPage;

