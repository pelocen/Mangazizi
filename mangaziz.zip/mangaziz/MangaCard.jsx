import { Link } from 'react-router-dom';
import { Star, Clock, CheckCircle, Pause } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const MangaCard = ({ manga, showStatus = true, showRating = true, className = '' }) => {
  const getStatusIcon = (status) => {
    switch (status) {
      case 'ongoing':
        return <Clock size={12} />;
      case 'completed':
        return <CheckCircle size={12} />;
      case 'hiatus':
        return <Pause size={12} />;
      default:
        return null;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ongoing':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'completed':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'hiatus':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Link 
      to={`/manga/${manga.id}`}
      className={`group block bg-card rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 ${className}`}
    >
      <div className="relative aspect-[3/4] overflow-hidden">
        <img
          src={manga.coverImage}
          alt={manga.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Status Badge */}
        {showStatus && (
          <div className="absolute top-2 left-2">
            <Badge 
              variant="secondary" 
              className={`text-xs font-medium ${getStatusColor(manga.status)}`}
            >
              <span className="flex items-center gap-1">
                {getStatusIcon(manga.status)}
                {manga.status.toUpperCase()}
              </span>
            </Badge>
          </div>
        )}

        {/* Rating Badge */}
        {showRating && (
          <div className="absolute top-2 right-2">
            <Badge variant="secondary" className="bg-black/50 text-white border-white/20">
              <Star size={12} className="fill-yellow-400 text-yellow-400 mr-1" />
              {manga.rating}
            </Badge>
          </div>
        )}

        {/* Latest Chapter Badge */}
        {manga.chapters && manga.chapters.length > 0 && (
          <div className="absolute bottom-2 left-2">
            <Badge variant="secondary" className="bg-primary/90 text-primary-foreground">
              Ch. {manga.chapters[manga.chapters.length - 1].number}
            </Badge>
          </div>
        )}

        {/* Tags */}
        {manga.tags && manga.tags.length > 0 && (
          <div className="absolute bottom-2 right-2">
            <Badge variant="secondary" className="bg-accent/90 text-accent-foreground text-xs">
              {manga.tags[0]}
            </Badge>
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-sm mb-1 line-clamp-2 group-hover:text-primary transition-colors">
          {manga.title}
        </h3>
        <p className="text-xs text-muted-foreground mb-2 line-clamp-1">
          by {manga.author}
        </p>
        
        {/* Genres */}
        <div className="flex flex-wrap gap-1 mb-2">
          {manga.genres.slice(0, 2).map((genre) => (
            <Badge 
              key={genre} 
              variant="outline" 
              className="text-xs px-2 py-0.5 border-muted-foreground/30"
            >
              {genre}
            </Badge>
          ))}
          {manga.genres.length > 2 && (
            <Badge 
              variant="outline" 
              className="text-xs px-2 py-0.5 border-muted-foreground/30"
            >
              +{manga.genres.length - 2}
            </Badge>
          )}
        </div>

        {/* Description */}
        <p className="text-xs text-muted-foreground line-clamp-2">
          {manga.description}
        </p>
      </div>
    </Link>
  );
};

export default MangaCard;

