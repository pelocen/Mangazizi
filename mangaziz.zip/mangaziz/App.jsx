import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import HomePage from './pages/HomePage';
import HotPage from './pages/HotPage';
import BrowsePage from './pages/BrowsePage';
import CreatorsPage from './pages/CreatorsPage';
import MyShelfPage from './pages/MyShelfPage';
import MangaDetailsPage from './pages/MangaDetailsPage';
import ReaderPage from './pages/ReaderPage';
import './App.css';

function App() {
  return (
    <div className="dark min-h-screen bg-background text-foreground">
      <Router>
        <Routes>
          {/* Reader page without navigation */}
          <Route path="/read/:mangaId/:chapterNumber" element={<ReaderPage />} />
          
          {/* All other pages with navigation */}
          <Route path="/*" element={
            <>
              <Navigation />
              <main className="pt-16 md:pt-20 pb-20 md:pb-8">
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/hot" element={<HotPage />} />
                  <Route path="/browse" element={<BrowsePage />} />
                  <Route path="/creators" element={<CreatorsPage />} />
                  <Route path="/shelf" element={<MyShelfPage />} />
                  <Route path="/manga/:id" element={<MangaDetailsPage />} />
                </Routes>
              </main>
            </>
          } />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
